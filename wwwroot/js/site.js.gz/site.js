﻿document.addEventListener("DOMContentLoaded", function () {
    particlesJS.load('particles-js', '/js/particles-config.js', function () {
        console.log('Particles.js loaded – callback');
    });
});
